package com.example.testproject.ui.start;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.testproject.R;

import static android.content.Context.SENSOR_SERVICE;
import static androidx.core.content.ContextCompat.getSystemService;

public class StartFragment extends Fragment {

    private StartViewModel startViewModel;

    private SensorManager mySensorManager;
    private SensorEventListener gyroListener;
    private Sensor myGyro;

    double roll;
    double pitch;
    double yaw;

    private double timestamp = 0.0;
    private double dt;

    private double rad_to_dgr = 180/ Math.PI;
    private static final float NS2S = 1.0f/1000000000.0f;

    TextView x;
    TextView y;
    TextView z;

    movePoint mv;

    Button btn1;

    int width;
    int height;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        startViewModel =
                ViewModelProviders.of(this).get(StartViewModel.class);
        View root = inflater.inflate(R.layout.fragment_start, container, false);

        x = (TextView) root.findViewById(R.id.x);
        y = (TextView) root.findViewById(R.id.y);
        z = (TextView) root.findViewById(R.id.z);

        mv = (movePoint)root.findViewById(R.id.mp);

        btn1=(Button)root.findViewById(R.id.btn1);

        mySensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
        myGyro = mySensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mv.initialize(height,width);
                pitch = 0;
                roll = 0;
                yaw = 0;
            }
        });


        mv.initialize(height,width);
        gyroListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                double gyroX = event.values[0];
                double gyroY = event.values[1];
                double gyroZ = event.values[2];

                width = mv.getWidth();
                height = mv.getHeight();

                dt = (event.timestamp - timestamp) * NS2S;
                timestamp = event.timestamp;

                if (dt - timestamp * NS2S != 0) {
                    pitch = pitch + gyroY * dt;
                    roll = roll + gyroX * dt;
                    yaw = yaw + gyroZ * dt;




                    x.setText("[X]:" + String.format("%.4f", event.values[0])+"   "+"[roll]" + String.format("%.4f", roll * rad_to_dgr));
                    y.setText("[Y]:" + String.format("%.4f", event.values[1])+"   "+"[pitch]" + String.format("%.4f", pitch * rad_to_dgr));
                    z.setText("[Z]:" + String.format("%.4f", event.values[2])+"   "+"[yaw]" + String.format("%.4f", yaw * rad_to_dgr));

                    mv.setX((float)(pitch * rad_to_dgr),width);
                    mv.setY((float)(roll * rad_to_dgr),height);
                    mv.invalidate();

                }

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };

        return root;
    }


    public void onResume() {
        super.onResume();
        mySensorManager.registerListener(gyroListener,myGyro,SensorManager.SENSOR_DELAY_GAME);
    }

    public void onPause() {
        super.onPause();
        mySensorManager.unregisterListener(gyroListener);
    }
    public void onStop() {
        super.onStop();
    }

}