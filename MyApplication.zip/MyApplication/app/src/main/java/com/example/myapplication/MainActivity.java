package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.sip.SipSession;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

class movePoint extends View{

    float x = 500;
    float y = 640;

    public movePoint(Context context) {
        super(context);
    }

    public movePoint(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

    }

    public movePoint(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    public void setX(float pitch, int width){
        if(pitch>60)
            pitch = 60;
        if(pitch<-60)
            pitch = -60;
        pitch+=60;

        this.x = (float)width/120*pitch;

    }

    public void setY(float roll,int height){
        if(roll>60)
            roll = 60;
        if(roll<-60)
            roll = -60;
        roll+=60;

        this.y = (float)height/120*roll;
    }

    public void initialize(int height,int width){
        this.x = width/2;
        this.y = height/2;
    }
    protected void onDraw(Canvas canvas){
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        paint.setColor(Color.WHITE);


        canvas.drawCircle(x,y,50,paint);

        Log.d("xyxy", "X: "+x+"Y:"+y);


    }

}

public class MainActivity extends AppCompatActivity{

    private SensorManager mySensorManager;
    private SensorEventListener gyroListener;
    private Sensor myGyro;

    double roll;
    double pitch;
    double yaw;

    private double timestamp = 0.0;
    private double dt;

    private double rad_to_dgr = 180/ Math.PI;
    private static final float NS2S = 1.0f/1000000000.0f;

    TextView x;
    TextView y;
    TextView z;

    movePoint mv;

    Button btn1;

    int width;
    int height;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        x = (TextView) findViewById(R.id.x);
        y = (TextView) findViewById(R.id.y);
        z = (TextView) findViewById(R.id.z);

        mv = (movePoint)findViewById(R.id.mp);

        btn1=(Button)findViewById(R.id.btn1);

        mySensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        myGyro = mySensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mv.initialize(height,width);
                pitch = 0;
                roll = 0;
                yaw = 0;
            }
        });


        mv.initialize(height,width);
        gyroListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                double gyroX = event.values[0];
                double gyroY = event.values[1];
                double gyroZ = event.values[2];

                dt = (event.timestamp - timestamp) * NS2S;
                timestamp = event.timestamp;

                if (dt - timestamp * NS2S != 0) {
                    pitch = pitch + gyroY * dt;
                    roll = roll + gyroX * dt;
                    yaw = yaw + gyroZ * dt;




                    x.setText("[X]:" + String.format("%.4f", event.values[0])+"   "+"[roll]" + String.format("%.4f", roll * rad_to_dgr));
                    y.setText("[Y]:" + String.format("%.4f", event.values[1])+"   "+"[pitch]" + String.format("%.4f", pitch * rad_to_dgr));
                    z.setText("[Z]:" + String.format("%.4f", event.values[2])+"   "+"[yaw]" + String.format("%.4f", yaw * rad_to_dgr));

                    mv.setX((float)(pitch * rad_to_dgr),width);
                    mv.setY((float)(roll * rad_to_dgr),height);
                    mv.invalidate();

                }

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };

    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        width = mv.getWidth();
        height = mv.getHeight();


    }

    protected void onResume() {
        super.onResume();
        mySensorManager.registerListener(gyroListener,myGyro,SensorManager.SENSOR_DELAY_GAME);
    }

    protected void onPause() {
        super.onPause();
        mySensorManager.unregisterListener(gyroListener);
    }
    protected void onStop() {
        super.onStop();
    }


}
